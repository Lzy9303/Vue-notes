#!/bin/sh -e
#set -x

if [ -f /config/.antminer ] ; then
    rm -f /config/.antminer
fi

if [ -f /config/.antminers ] ; then
    rm -f /config/.antminers
fi

if [ -f /tmp/b7mods ] ; then
    rm -f /tmp/b7mods
fi

rm -f /usr/bin/bmminer
cp bmminer /usr/bin/bmminer
sleep 2s
chmod 755 /usr/bin/bmminer

rm -f /etc/init.d/bitmainer_setup.sh
cp bitmainer_setup.sh /etc/init.d/bitmainer_setup.sh
chmod 755 /etc/init.d/bitmainer_setup.sh

if [ ! -f /usr/bin/xxd ] ; then
    cp xxd /usr/bin/xxd
    chmod 755 /usr/bin/xxd
fi

if [ ! -f /config/voltage ] ; then
    cp voltage /config/voltage
fi

rm -f /usr/bin/compile_time
cp compile_time /usr/bin/compile_time

rm -f /www/pages/miner_stats.html
cp miner_stats.html /www/pages/miner_stats.html    

rm -f /www/pages/upgrade.html
cp upgrade.html /www/pages/upgrade.html

rm -f /www/pages/cg-bin/create_conf_backup.cgi
cp create_conf_backup.cgi /www/pages/cgi-bin/create_conf_backup.cgi

rm -f /www/pages/cg-bin/get_miner_status.cgi
cp get_miner_status.cgi /www/pages/cgi-bin/get_miner_status.cgi

rm -f /www/pages/cg-bin/minerAdvanced.cgi
cp minerAdvanced.cgi /www/pages/cgi-bin/minerAdvanced.cgi

rm -f /www/pages/cg-bin/minerConfiguration.cgi
cp minerConfiguration.cgi /www/pages/cgi-bin/minerConfiguration.cgi

rm -f /www/pages/cg-bin/set_miner_conf.cgi
cp set_miner_conf.cgi /www/pages/cgi-bin/set_miner_conf.cgi

rm -f /www/pages/cg-bin/upgrade.cgi
cp upgrade.cgi /www/pages/cgi-bin/upgrade.cgi

rm -f /www/pages/cg-bin/upgrade_clear.cgi
cp upgrade_clear.cgi /www/pages/cgi-bin/upgrade_clear.cgi

rm -f /www/pages/cg-bin/upload_conf.cgi
cp upload_conf.cgi /www/pages/cgi-bin/upload_conf.cgi

rm -f /sbin/monitorcg
cp monitorcg /sbin/monitorcg


sync
